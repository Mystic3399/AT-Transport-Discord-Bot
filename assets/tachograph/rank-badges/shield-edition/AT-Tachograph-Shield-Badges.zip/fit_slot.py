"""Fit a badge to any approved tachograph card slot, preserving aspect ratio."""
import argparse
import csv
from pathlib import Path

from PIL import Image, ImageOps

root = Path(__file__).resolve().parent
with (root / "placements.csv").open(newline="") as table:
    slots = {Path(row["file"]).stem: row for row in csv.DictReader(table)}

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("rank", choices=sorted(p.stem for p in (root / "unlocked").glob("*.webp")))
parser.add_argument("state", choices=("unlocked", "locked"))
parser.add_argument("slot", choices=slots)
parser.add_argument("output", type=Path)
args = parser.parse_args()
slot = slots[args.slot]
size = (int(slot["width"]), int(slot["height"]))
with Image.open(root / args.state / f"{args.rank}.webp") as source:
    badge = source.convert("RGBA")
    badge = badge.crop(badge.getbbox())
    badge = ImageOps.contain(badge, size, Image.Resampling.LANCZOS)
canvas = Image.new("RGBA", size)
canvas.alpha_composite(badge, ((size[0]-badge.width)//2, (size[1]-badge.height)//2))
canvas.save(args.output)
